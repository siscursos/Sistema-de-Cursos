package db;

public class DatabaseConnect extends MysqlConnect{
}