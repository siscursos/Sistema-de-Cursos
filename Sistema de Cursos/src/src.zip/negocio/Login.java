package negocio;

public class Login {
	private String login;
	private String senha;
	
	public Login(String l, String s){
		login = l;
		senha = s;
		
	}
	
	public void criaLogin(){
		
		
	}
}
